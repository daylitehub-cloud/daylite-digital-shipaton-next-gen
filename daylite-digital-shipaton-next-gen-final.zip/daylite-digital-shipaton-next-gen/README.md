# Daylite Digital — Shipaton 2026 Repository Package

**Project:** Daylite Digital  
**Competition target:** RevenueCat Shipaton 2026 — Next Gen  
**Project status represented by this repository:** Daylite Digital Shopify storefront customizations plus a documented RevenueCat integration plan. The actual mobile application source and working RevenueCat SDK integration were not found in the supplied materials.

## What Daylite Digital is

Daylite Digital is a Namibian-founded digital tourism marketplace and marketing platform intended to connect travellers with accommodation providers and tourism partners. Its broader ecosystem includes destination content, accommodation discovery and booking facilitation, and an ambassador-led customer-acquisition programme. This repository does **not** contain the full live Shopify store, its catalogue, provider systems, or the broader ecosystem.

## Problem and approach

Travellers and tourism partners can face fragmented discovery and communication across destinations and providers. Daylite Digital's broader platform aims to make travel-related discovery and partner connection more accessible through a digital storefront and supporting services. The included files are a small subset of Shopify theme customizations related to an accommodation-provider application page; they do not implement the broader marketplace independently.

## What is actually included

- Two Daylite-specific Shopify Liquid snippets: accommodation-provider styling and application-page presentation overrides.
- One Shopify JSON product template for the provider-application product.
- The one-line Daylite conditional-render hook extracted from the product-information section, preserved separately so the third-party section does not need to be redistributed.
- Documentation describing the source scope, dependencies, licensing boundary, setup context, and RevenueCat implementation status/plan.
- `revenuecat/README.md` documenting the intended RevenueCat architecture without fabricated SDK code.

There is no `app/` directory because no mobile or standalone web application source was found. No fabricated application, purchase flow, SDK wrapper, sample product catalogue, or placeholder source has been added.

## How to use the included files

These files are **theme fragments**, not a complete Shopify theme and not a standalone application. They are intended for review and controlled integration into the matching Shopify theme:

1. Back up the target theme before making changes.
2. Confirm the target theme has a compatible `product-information` section and the Atelier-specific product blocks referenced by `product.provider-application.json`.
3. Copy the snippets into the theme's `snippets/` directory.
4. Add or review the product template in `templates/` and assign it only to the intended provider-application product.
5. Confirm that the target `sections/product-information.liquid` includes the hook in `storefront/theme-fragments/patches/product-information-daylite-hook.liquid`. That hook was present at the first line of the supplied export's section file, but the full third-party section file is not redistributed here. Merge it only if absent.
6. Test the application page in a duplicate theme on desktop and mobile. Verify the actual form submission and confirmation workflow separately; the label override alone does not create a submission backend or email workflow.

The template also references a SmartBot chat-button app block. The corresponding third-party app must be installed and available in the target store for that block to render. The `accomo-provider-styles.liquid` snippet was not referenced elsewhere in the supplied ZIP, so its intended insertion point must be confirmed before use.

## Technology in this repository

- Shopify Liquid snippets
- Shopify JSON theme-template configuration
- CSS and a small browser-side JavaScript button-label adjustment
- Markdown documentation

No Swift, SwiftUI, Kotlin, Java, Gradle, Xcode project, Flutter/Dart, React Native, Node/TypeScript application, `package.json`, `pubspec.yaml`, Podfile, Android manifest, or native build configuration was found in the supplied ZIP or the available workspace scan.

## RevenueCat status

RevenueCat is planned for the Daylite Digital application, but the working SDK integration is **blocked pending resolution of the current Shopify server error by Shopify**. No RevenueCat SDK, initialization, entitlement/offering/product configuration, purchase implementation, paywall implementation, or purchase-state handling was found in the supplied source. See [`docs/REVENUECAT.md`](docs/REVENUECAT.md) and [`revenuecat/README.md`](revenuecat/README.md). No fabricated RevenueCat implementation has been added.

## Ownership and third-party materials

The original Daylite-specific snippets and the authored documentation are licensed under the MIT License in [`LICENSE`](LICENSE). The product template is included as Daylite storefront configuration, but its references to Shopify theme sections, Atelier-specific blocks, and a SmartBot app block are dependencies, not a grant of rights over those components. The full Atelier theme, Shopify platform code, SmartBot app code, and externally served fonts are not included. See [`docs/THIRD_PARTY_NOTICES.md`](docs/THIRD_PARTY_NOTICES.md) for the scope and unresolved license-verification notes.

## Competition context

This is a cleaned, documented package of the legitimate Daylite-specific source fragments found in the supplied Shopify theme export, with the intended RevenueCat integration documented transparently. It is not yet a complete mobile application repository. The actual application source and working RevenueCat integration must be added after the Shopify server issue is resolved before the project can truthfully be represented as a completed RevenueCat-backed application. See [`docs/SHIPATON_NEXT_GEN.md`](docs/SHIPATON_NEXT_GEN.md) for the scope and limitations.

# RevenueCat — Daylite Digital Integration

## Current status

**PLANNED / BLOCKED — not yet implemented.**

RevenueCat is part of the intended Daylite Digital application architecture for monetization. The actual RevenueCat SDK integration will only be implemented after the current Shopify server error affecting the Daylite Digital environment has been resolved by Shopify.

This directory deliberately contains **no fabricated SDK source, fake purchase flow, fake API key, fake entitlement IDs, or simulated RevenueCat implementation**.

## Intended implementation

Once the Shopify server issue is resolved and the actual application source is available, the implementation will be completed in the real Daylite Digital application rather than in this Shopify theme fragment package.

The implementation is expected to include, as applicable to the final application:

1. RevenueCat SDK installation for the selected mobile framework/platform.
2. Secure configuration using the appropriate public client SDK key; secrets will not be committed.
3. RevenueCat initialization during application startup.
4. Product and offering configuration in the RevenueCat dashboard and corresponding app-store/web products where applicable.
5. Purchase initiation from the application's monetization UI.
6. Purchase restoration where supported.
7. Customer identity handling and RevenueCat customer state synchronization.
8. Entitlement/customer-info handling to unlock the relevant Daylite Digital premium functionality.
9. Error/loading states and a testable purchase path.
10. Documentation and a demo path that can be traced directly to the submitted source code.

## Dependency / blocker

The implementation is intentionally deferred until the current Shopify server error is fixed by Shopify. This repository records the intended architecture so the implementation can be added transparently after the blocker is removed.

## Important submission statement

At the time this repository was prepared, no working RevenueCat SDK integration was found in the supplied Daylite Digital source. Therefore this repository must not claim that RevenueCat purchases or subscriptions are already operational.

Official RevenueCat SDK installation and configuration documentation:
https://www.revenuecat.com/docs/getting-started/installation
https://www.revenuecat.com/docs/getting-started/configuring-sdk

# RevenueCat Shipaton 2026 — Next Gen Submission Notes

## Project

- **Project:** Daylite Digital
- **Competition:** RevenueCat Shipaton 2026
- **Target category:** Next Gen
- **Repository status:** Cleaned Daylite Digital Shopify source fragments plus transparent implementation documentation.

## Current implementation status

The supplied source is primarily a Shopify storefront/theme export. No separate mobile application source or working RevenueCat SDK integration was found in the supplied materials.

RevenueCat is intended for the Daylite Digital application monetization architecture, but implementation is deliberately deferred until the current Shopify server error has been fixed by Shopify. No fabricated application or RevenueCat code has been added.

## Why the RevenueCat material is documented now

The repository records the intended RevenueCat architecture and implementation sequence so that the final application integration can be added to the same project transparently once the technical blocker is resolved.

## What is included

- Legitimate Daylite Digital Shopify theme fragments found in the supplied export.
- Architecture and setup documentation.
- RevenueCat integration status and implementation plan.
- Open-source licensing and third-party scope documentation.
- Submission notes that clearly distinguish implemented source from planned work.

## What is not included

- A fabricated mobile application.
- Fabricated RevenueCat SDK calls.
- Fake RevenueCat project/product/entitlement identifiers.
- Private Shopify credentials or server secrets.
- A claim that purchases or subscriptions are currently working.

## Finalization required before claiming a working RevenueCat app

After Shopify resolves the server issue, the final submission should include the actual application source, its dependency/build files, the real RevenueCat SDK integration, real testable monetization configuration, and a demo video that matches the submitted source.

## Official submission context

RevenueCat's current Shipaton guidance states that Next Gen student entrants can submit a demo and public open-source repository instead of a store listing, but the repository must contain the code, setup instructions and visible open-source license needed to validate the project. The submission materials must accurately represent what is implemented.

Official submission guide:
https://www.revenuecat.com/blog/engineering/how-to-submit-your-app-for-shipaton

# Setup and Review Instructions

## Prerequisites

- Access to a Shopify development store or a duplicate of the intended store theme.
- A compatible copy of the original Atelier theme or another theme whose product-section and block architecture has been deliberately adapted.
- The SmartBot app installed if the template's configured chat-button block is to be used.

## Review the fragments

This repository has no standalone run command, package manager, app build, or local development server. Review the Liquid and JSON files directly. Validate the JSON syntax before importing the template.

## Integrate safely

1. Duplicate the target Shopify theme and work only in the duplicate.
2. Review `docs/ARCHITECTURE.md` and `docs/THIRD_PARTY_NOTICES.md` before copying any fragment.
3. Add the two snippets under the target theme's `snippets/` directory.
4. Add `product.provider-application.json` only after verifying that the referenced section and blocks exist in the target theme.
5. Verify the `product-information` conditional hook that renders `provider-application-overrides` for this template. If absent, merge the fragment in `storefront/theme-fragments/patches/product-information-daylite-hook.liquid`. Do not replace the full section with a fragment.
6. Assign the template to a test product and test on desktop/mobile.
7. Confirm actual application submission, order handling, data collection, and applicant email behavior separately. These are not implemented by the included fragments.

## Validation

Use Shopify's theme preview and theme-check tooling appropriate to the target theme. This package does not claim to have passed Shopify Theme Check or a live storefront integration test. Local packaging validation only confirms the included JSON parses, expected files exist, and the ZIP can be extracted.

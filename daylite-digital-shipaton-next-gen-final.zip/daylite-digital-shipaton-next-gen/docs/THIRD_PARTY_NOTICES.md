# Third-Party Notices and License Boundaries

This package deliberately excludes the bulk of the supplied Shopify `Copy of Atelier` theme because the original export did not include a verifiable license file and its redistribution terms were not established here.

## Shopify / Atelier theme architecture

The included `product.provider-application.json` refers to a `product-information` section and theme block types including `_product-media-gallery` and `_product-details`. Those implementations are not included. The supplied theme's `sections/product-information.liquid` was inspected but omitted because it is substantially theme code. The package does not claim the Atelier theme is MIT-licensed or open source.

## SmartBot app block

The product template references the Shopify app block `shopify://apps/smartbot/blocks/chat-button/d9407b81-7d3e-4612-91c3-2020086e2073`. This is a configuration reference only; SmartBot application source is not included. Availability and terms depend on the app and store installation. No license claim is made.

## Google Fonts

`accomo-provider-styles.liquid` imports Cormorant Garamond and Inter from `fonts.googleapis.com`. Font binaries are not included in this package. Fonts are fetched externally when the snippet is used. This notice records the external dependency; it does not substitute for reviewing the applicable font licenses and service terms.

## Shopify Liquid and JSON configuration

The included files use Shopify theme conventions and Liquid syntax. The package does not include Shopify platform source code, and this repository license does not grant rights to Shopify services or third-party platform components.

## Original Daylite-specific material

The two included snippets are identified as Daylite-specific storefront customizations from the supplied export. The repository-authored documentation is also original to this package. The MIT license scope is intentionally limited as described in `LICENSE`; it does not relicense omitted or referenced third-party code.

## Other inspected theme files

- `sections/product-information.liquid` was omitted due to substantial theme code; the Daylite-specific conditional render hook is described in `docs/ARCHITECTURE.md`.
- `blocks/ai_gen_block_d8ce204.liquid` and `blocks/ai_gen_block_e7d0dc6.liquid` were omitted because they appear to be generic theme/editor-generated layout blocks and were not established as essential Daylite-owned source.
- Generic `collection.json`, `index.json`, and `page.json` templates were omitted because they were not established as Daylite-specific customizations.

No third-party license has been guessed. Review the original theme purchase/license terms before redistributing any additional Atelier files.

# Architecture and Source Inventory

## Repository boundary

This package is a partial extraction from the Shopify theme export `Copy of Atelier`. It is not a complete theme and does not contain a mobile app or a standalone web application.

## Included source files

| File | Purpose | Runtime dependency / note |
|---|---|---|
| `storefront/theme-fragments/snippets/accomo-provider-styles.liquid` | CSS styling for a Daylite accommodation/provider content layout | Must be rendered or otherwise included by a compatible Shopify theme; no reference to it was found in the supplied export |
| `storefront/theme-fragments/snippets/provider-application-overrides.liquid` | Hides quantity/accelerated checkout controls and relabels the product add button to “SEND APPLICATION NOW” | Must be rendered by a compatible product section; this changes presentation only, not the underlying submission backend |
| `storefront/theme-fragments/patches/product-information-daylite-hook.liquid` | Preserves the Daylite conditional render hook found at the first line of the supplied product section | Merge into a compatible `sections/product-information.liquid` only if the hook is absent; do not replace the full section with this fragment |
| `storefront/theme-fragments/templates/product.provider-application.json` | Shopify product template configuration for the provider application | Requires a compatible `product-information` section, Atelier-specific product blocks, and the referenced SmartBot chat-button app block |

## Inspected but not redistributed

- `sections/product-information.liquid`: mostly a theme section; its first line conditionally renders `provider-application-overrides` for `product.provider-application`. The full section is not included because it contains substantial third-party theme code; the Daylite hook itself is preserved as a separate patch fragment.
- `blocks/ai_gen_block_d8ce204.liquid`: generic “Products available” presentation block; not established as essential Daylite-specific source.
- `blocks/ai_gen_block_e7d0dc6.liquid`: generic magazine-style editorial layout block; not established as essential Daylite-specific source.
- `templates/collection.json`, `templates/index.json`, and `templates/page.json`: general theme templates without sufficient evidence that they are Daylite-specific work; excluded to avoid repackaging the theme wholesale.
- Other Atelier theme files and assets: excluded because their licensing terms were not established for redistribution.

## Request and purchase flow

The included files do not implement an application submission service, email workflow, accommodation booking backend, payment processing, or in-app purchase flow. The button-label script only adjusts visible text in the storefront. A zero-price Shopify product or a button label by itself is not proof of an application-processing backend.

## Broader Daylite Digital ecosystem

The broader business includes a Shopify storefront and tourism/partner services, but this repository contains only the theme fragments above. No backend service, API contract, mobile client, database schema, or production deployment configuration was found in the available source files.
